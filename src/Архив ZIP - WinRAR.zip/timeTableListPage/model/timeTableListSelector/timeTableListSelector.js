

export const getTimeTableData = (state) =>
    state.timeTable.data

export const getTimeTableLoading = (state) =>
    state.timeTable.loading
