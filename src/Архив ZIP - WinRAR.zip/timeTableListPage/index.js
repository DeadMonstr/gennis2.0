export {TimeTableListPage} from "./ui/timeTableListPage";
export {default as timeTable} from "./model/timeTableListSlice/timeTableListSlice";